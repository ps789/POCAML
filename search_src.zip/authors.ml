(* TODO: set the value below *)
let hours_worked = [20; 20; 20; 20]
